const buttonContainer = document.getElementById('button-container');
    const popupOverlay = document.getElementById('popupOverlay');
    const closeBtn = document.getElementById('closeBtn');
    const iframe = document.getElementById('playerIframe');
    const episodeSlider = document.getElementById('episodeSlider');
    const episodeButtons = document.getElementById('episodeButtons');

    function generateButtons(videos) {
      buttonContainer.innerHTML = '';
      videos.forEach((video) => {
        const button = document.createElement('button');
        button.classList.add('image-button');
        button.onclick = () => loadPlayer(video);

        const img = document.createElement('img');
        img.src = video.image;
        img.alt = `Poster ${video.title}`;

        const titleOverlay = document.createElement('div');
        titleOverlay.classList.add('title-overlay');
        titleOverlay.textContent = video.title;

        button.appendChild(img);
        button.appendChild(titleOverlay);

        const col = document.createElement('div');
        col.classList.add('col-4', 'col-sm-6', 'col-md-4', 'col-lg-3');
        col.appendChild(button);
        buttonContainer.appendChild(col);
      });
    }

    function loadPlayer(video) {
  iframe.src = video.isSeries ? video.episodes[0].url : video.url;
  popupOverlay.style.display = 'flex';
  setTimeout(() => {
    popupOverlay.style.opacity = 1;
  }, 10);

  if (video.isSeries) {
    loadEpisodes(video);
  } else {
    episodeSlider.style.display = 'none';
  }

  // Hide close button after 2 seconds
  setTimeout(() => {
    closeBtn.style.display = 'none';
  }, 2000);
}


    function loadEpisodes(video) {
      episodeSlider.style.display = 'block';
      episodeButtons.innerHTML = '';
      const seriesButtons = document.createElement('div');
      seriesButtons.classList.add('series-buttons');

      video.episodes.forEach((episode) => {
        const episodeButton = document.createElement('button');
        episodeButton.textContent = episode.title;
        episodeButton.onclick = () => loadEpisode(episode.url);
        seriesButtons.appendChild(episodeButton);
      });

      episodeButtons.appendChild(seriesButtons);
    }

    function loadEpisode(url) {
      iframe.src = url;
    }

    function closePlayer() {
      popupOverlay.style.opacity = 0;
      setTimeout(() => {
        popupOverlay.style.display = 'none';
        iframe.src = '';
        episodeSlider.style.display = 'none';
      }, 500);

      // Ensure the close button is reset for next use
      closeBtn.style.display = 'block';
    }

    closeBtn.addEventListener('click', closePlayer);

    // Add click event listener to the overlay to show close button again
    popupOverlay.addEventListener('click', (event) => {
  // Cek jika klik berada di luar area iframe (bukan di area tombol close)
  if (event.target === popupOverlay) {
    // Tampilkan tombol close
    closeBtn.style.display = 'block';

    // Sembunyikan tombol close setelah 2 detik
    setTimeout(() => {
      closeBtn.style.display = 'none';
    }, 2000);
  }
});
    function searchMovies() {
      const searchTerm = document.getElementById('searchInput').value.toLowerCase();
      const filteredVideos = videos.filter((video) =>
        video.title.toLowerCase().includes(searchTerm)
      );
      generateButtons(filteredVideos);
    }

    function setLightMode() {
      document.body.classList.remove('dark-mode');
      const navbar = document.querySelector('.navbar');
      navbar.classList.remove('navbar-dark', 'bg-dark');
      navbar.classList.add('navbar-light', 'bg-light');
      localStorage.setItem('theme', 'light');
    }

    function setDarkMode() {
      document.body.classList.add('dark-mode');
      const navbar = document.querySelector('.navbar');
      navbar.classList.remove('navbar-light', 'bg-light');
      navbar.classList.add('navbar-dark', 'bg-dark');
      localStorage.setItem('theme', 'dark');
    }

    document.addEventListener('DOMContentLoaded', () => {
      const savedTheme = localStorage.getItem('theme');
      if (savedTheme === 'dark') {
        setDarkMode();
      } else {
        setLightMode();
      }

      generateButtons(videos);
    });