const moviesPerPage = 9; // Jumlah film per halaman
let currentPage = 1; // Halaman saat ini

function generateButtons(videos) {
  buttonContainer.innerHTML = '';

  // Hitung indeks awal & akhir berdasarkan halaman
  const startIndex = (currentPage - 1) * moviesPerPage;
  const endIndex = startIndex + moviesPerPage;
  const paginatedVideos = videos.slice(startIndex, endIndex);

  paginatedVideos.forEach((video) => {
    const button = document.createElement('button');
    button.classList.add('image-button');
    button.onclick = () => loadPlayer(video);

    const img = document.createElement('img');
    img.src = video.image;
    img.alt = `Poster ${video.title}`;

    const titleOverlay = document.createElement('div');
    titleOverlay.classList.add('title-overlay');
    titleOverlay.textContent = video.title;

    button.appendChild(img);
    button.appendChild(titleOverlay);

    const col = document.createElement('div');
    col.classList.add('col-4', 'col-sm-6', 'col-md-4', 'col-lg-3');
    col.appendChild(button);
    buttonContainer.appendChild(col);
  });

  updatePaginationButtons(videos.length);
}

// Fungsi untuk update tombol pagination
function updatePaginationButtons(totalMovies) {
  const totalPages = Math.ceil(totalMovies / moviesPerPage);
  const paginationContainer = document.getElementById('pagination-container');

  paginationContainer.innerHTML = ''; // Kosongkan pagination sebelumnya

  // Teks indikator halaman (Page X of Y)
  const pageIndicator = document.createElement('span');
  pageIndicator.textContent = `Page ${currentPage} of ${totalPages}`;
  pageIndicator.classList.add('page-indicator');

  const prevButton = document.createElement('button');
  prevButton.textContent = 'Previous';
  prevButton.disabled = currentPage === 1;
  prevButton.onclick = () => {
    if (currentPage > 1) {
      currentPage--;
      generateButtons(videos);
    }
  };

  const nextButton = document.createElement('button');
  nextButton.textContent = 'Next';
  nextButton.disabled = currentPage === totalPages;
  nextButton.onclick = () => {
    if (currentPage < totalPages) {
      currentPage++;
      generateButtons(videos);
    }
  };

  paginationContainer.appendChild(prevButton);
  paginationContainer.appendChild(pageIndicator);
  paginationContainer.appendChild(nextButton);
}


// Fungsi untuk pencarian yang juga mempertahankan pagination
function searchMovies() {
  const searchTerm = document.getElementById('searchInput').value.toLowerCase();
  const filteredVideos = videos.filter((video) =>
    video.title.toLowerCase().includes(searchTerm)
  );
  
  currentPage = 1; // Reset ke halaman 1 setelah pencarian
  generateButtons(filteredVideos);
}
